Performance Monitor

A lightweight performance monitoring script for Node.js applications.

Contents:
- `perf_monitor.js` - sample script that logs memory and event-loop lag metrics periodically.

Notes:
- This is a simple example. Integrate with your logging/telemetry for production usage.