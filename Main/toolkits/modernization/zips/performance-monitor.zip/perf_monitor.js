// perf_monitor.js
// Simple Node.js performance monitor

function logMetrics() {
  const mem = process.memoryUsage();
  const metrics = {
    rss: mem.rss,
    heapTotal: mem.heapTotal,
    heapUsed: mem.heapUsed,
    external: mem.external,
    timestamp: Date.now()
  };
  console.log('METRICS', JSON.stringify(metrics));
}

if (require.main === module) {
  console.log('Starting perf monitor. Press CTRL+C to stop.');
  setInterval(logMetrics, 5000);
}

module.exports = { logMetrics };