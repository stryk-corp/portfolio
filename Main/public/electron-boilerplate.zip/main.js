// main.js - minimal Electron main process example (safe, does not require launching here)
const { app, BrowserWindow, ipcMain } = require('electron');

function createWindow() {
  const win = new BrowserWindow({ width: 800, height: 600, webPreferences: { nodeIntegration: true, contextIsolation: false } });
  win.loadFile('index.html');
}

ipcMain.handle('echo', async (event, msg) => {
  return `Echo from main: ${msg}`;
});

app.whenReady().then(createWindow);

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});