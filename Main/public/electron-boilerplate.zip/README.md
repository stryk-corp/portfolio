Electron Boilerplate

A minimal Electron starter to demonstrate IPC and packaging basics.

Contents:
- `main.js` - basic Electron main process example
- `renderer.js` - simple renderer-side invocation

Notes:
- This is a minimal starter. To run, install Electron in a Node environment and run `node main.js` or `electron .` (instructions in file).