// config_manager.js
const fs = require('fs');

function loadConfig(basePath = 'config.json', env = process.env.NODE_ENV || 'development') {
  let base = {};
  try { base = JSON.parse(fs.readFileSync(basePath, 'utf8')); } catch (e) {}
  const envPath = `config.${env}.json`;
  let envConfig = {};
  try { envConfig = JSON.parse(fs.readFileSync(envPath, 'utf8')); } catch (e) {}
  return Object.assign({}, base, envConfig);
}

if (require.main === module) {
  console.log('Loaded config:', loadConfig());
}

module.exports = { loadConfig };