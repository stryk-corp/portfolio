Config Manager

Utilities for managing application configuration across environments.

Contents:
- `config_manager.js` - simple example that loads JSON config and merges environment overrides.

Notes:
- Extend this with secure secret storage for production.