// legacy_wrapper_example.js
// Example: wrap a SOAP call in a REST endpoint (mocked SOAP client)

const express = require('express');
const app = express();
app.use(express.json());

// Mock SOAP client function
async function callLegacySoap(method, args) {
  // Simulate network delay
  await new Promise(r => setTimeout(r, 150));
  return { success: true, method, args, data: { id: 1, name: 'Legacy Record' } };
}

app.get('/api/legacy/:id', async (req, res) => {
  try {
    const result = await callLegacySoap('GetRecord', { id: req.params.id });
    res.json({ success: true, data: result.data });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

if (require.main === module) {
  app.listen(3100, () => console.log('Legacy wrapper demo listening on http://localhost:3100'));
}

module.exports = { app, callLegacySoap };