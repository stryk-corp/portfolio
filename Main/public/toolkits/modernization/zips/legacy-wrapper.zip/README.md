Legacy API Wrapper

This toolkit contains a small example to wrap a SOAP endpoint with a RESTful interface.

Contents:
- `legacy_wrapper_example.js` - example Node.js module showing how to call a SOAP service and expose a simple Express endpoint.

Notes:
- This is an example and uses a mocked SOAP client to avoid external calls. Replace the mock with a real SOAP client for production.